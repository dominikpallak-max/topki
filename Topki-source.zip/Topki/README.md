# Topki

Plugin na serwer **Paper 1.21.11** z rankingami graczy (topkami).

## Funkcje

- **Tablice w świecie** z top 10 dla każdej kategorii, odświeżane co 2 sekundy
- **Kliknięcie tablicy** otwiera TOP 50 danej kategorii
- **Menu `/topki`** z pozycją gracza w każdej kategorii i jego statystykami
- **Stronicowany TOP 50** z główkami graczy
- **Nagrody** wykonywane przy resecie dla gracza z 1. miejsca (konfigurowalne)

### Kategorie

| Kategoria | Co liczy |
|-----------|----------|
| `kills` | Zabójstwa innych graczy |
| `playtime` | Czas spędzony na serwerze |
| `deaths` | Liczba śmierci |
| `killstreak` | Najdłuższa seria zabójstw bez śmierci |
| `stone` | Ilość wykopanego kamienia |
| `pearls` | Liczba rzuconych pereł |

## Instalacja

1. Pobierz `Topki-1.0.jar` z zakładki **Actions** (artefakt **Topki-jar**) albo z sekcji **Releases**.
2. Wrzuć jar do folderu `plugins/` na serwerze Paper 1.21.11.
3. Zrestartuj serwer. Pliki `config.yml`, `stats.yml` i `boards.yml` pojawią się w `plugins/Topki/`.

## Komendy

| Komenda | Opis | Uprawnienie |
|---------|------|-------------|
| `/topki` | Otwiera menu topek | każdy |
| `/topki tablica <kategoria>` | Stawia tablicę w bloku, na który patrzysz | `topki.admin` |
| `/topki usun <id>` | Usuwa tablicę o podanym id | `topki.admin` |
| `/topki lista` | Pokazuje wszystkie tablice i ich id | `topki.admin` |
| `/topki reset` | Rozdaje nagrody 1. miejsca i zeruje statystyki | `topki.admin` |

Alias: `/topka`.

## Konfiguracja nagród

Plik `plugins/Topki/config.yml`:

```yaml
rewards:
  KILLS:
    - "give %player% diamond 5"
  PLAYTIME: []
```

Komendy są wykonywane z konsoli. `%player%` zostaje zastąpione nickiem zwycięzcy.

## Budowanie ze źródeł

Wymagane: JDK 21 i Maven.

```
mvn package
```

Gotowy plik: `target/Topki-1.0.jar`.

## Uwagi

- Statystyki zapisują się co 5 minut i przy wyłączeniu serwera.
- Tablice stoją na bloku, który wskazałeś. Możesz postawić pod nimi kamień dla wyglądu.
- Plugin jest napisany pod Paper. Na Spigocie czy Bukkit może nie działać (wymaga API tablic `TextDisplay` i `Interaction`).

## Licencja

Do uzupełnienia.
